<!DOCTYPE html>
<html>

<div id="footer">
<hr>
	Qamar Abdikadir 2020 &copy;
</div>

</html>