<!DOCTYPE html>
<html>
<head>

<title>Home Page</title>
<link rel="stylesheet" href="styles.css">

<meta charset="UTF-8">
<meta name="description" content="Home Page">
<meta name="author" content="Qamar Abdikadir">
<!-- Favicon-->
<link rel="icon" type="image/png" sizes="32x32" href="gear.png">

</head>


</html>